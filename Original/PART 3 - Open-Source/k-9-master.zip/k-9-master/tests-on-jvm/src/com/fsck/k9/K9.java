package com.fsck.k9;

public class K9 {
    public static boolean DEBUG = false;
}
